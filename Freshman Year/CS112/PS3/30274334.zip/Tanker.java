
public class Tanker extends Ship{
	/*
	 * construct tanker objects to be called "Tanker" and have length 3
	 */
	
	public Tanker() {
		super("Tanker", 3);
		

		

	}
	/*
	 * returns a boolean value depending on whether the ship has been hit once or not
	 */
	
	public boolean isSunk() {
		if (this.getNumHits() >= 1) {
			return true;
		}
		return false;
	}
	
	
	
	public static void main() {
		Tanker t = new Tanker();
		System.out.println(t);
		System.out.println("before it is hit: " + t.isSunk());
		t.applyHit();
		System.out.println("after it is hit: " + t.isSunk());
	}
	
}
