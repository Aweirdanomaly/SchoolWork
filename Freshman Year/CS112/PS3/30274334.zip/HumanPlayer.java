import java.util.*;
public class HumanPlayer extends Player{

	/*
	 *  takes string "playerName" and calls the constructor of the superclass to initialize inherited fields
	 */
	public HumanPlayer(String playerName) {
		super(playerName);
		
	}
	/*
	 * nextGuess - takes in a Scanner "console" and a Board "otherBoard" and returns a Guess object
	 * representing the player's guess. Overrides nextGuess method.
	 */
	
	public Guess nextGuess(Scanner console, Board otherBoard) {
		System.out.println("Enter your guess.");
		System.out.print("	row: ");

		int row = console.nextInt();
		System.out.print("     column: ");
		int col = console.nextInt();

	Guess g = new Guess(row, col);
	return g;
		
	
      
	}
	
}
