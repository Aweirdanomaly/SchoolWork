import java.util.Scanner;

public class ComputerPlayer extends Player{
	private Guess twoturnsGuess;
	private Guess previousGuess;
	private Guess currentGuess;
	
	
	public ComputerPlayer(String playerName) {
		super(playerName);
		previousGuess = null;
		twoturnsGuess = null;
		}
	
	
	public Guess nextGuess(Scanner console, Board otherBoard) {
		
		
		/*
		if (currentGuess == null) {
			twoturnsGuess = previousGuess;
			previousGuess = currentGuess;
			currentGuess = super.nextGuess(console, otherBoard);
			return currentGuess;
		}
		*/
		if (otherBoard.previousHit(previousGuess.getRow(), previousGuess.getColumn()) && otherBoard.sunkShipAt(previousGuess.getRow(), previousGuess.getColumn())== false) {
			twoturnsGuess = previousGuess;
			previousGuess = currentGuess;
			currentGuess = smartGuess(this, otherBoard);
			return currentGuess;
		}

		twoturnsGuess = previousGuess;
		previousGuess = currentGuess;
		currentGuess = super.nextGuess(console, otherBoard);
		return currentGuess;
		
		
		
	}
	
	
	public Guess smartGuess(ComputerPlayer comp, Board otherBoard) {
		Guess res;
		
	//	if (twoturnsGuess == null || otherBoard.previousMiss(twoturnsGuess.getRow(), twoturnsGuess.getColumn())) {
			if (otherBoard.hasBeenTried(previousGuess.getRow()+1, previousGuess.getColumn()) == false && previousGuess.getRow()+1 <8) {
				res = new Guess(previousGuess.getRow()+1, previousGuess.getColumn());
			}
			if (otherBoard.hasBeenTried(previousGuess.getRow()-1, previousGuess.getColumn()) == false && previousGuess.getRow()-1 >=0) {
				res = new Guess(previousGuess.getRow()-1, previousGuess.getColumn());
			}
			if (otherBoard.hasBeenTried(previousGuess.getRow(), previousGuess.getColumn()+1) == false && previousGuess.getColumn()+1 <8) {
				res = new Guess(previousGuess.getRow(), previousGuess.getColumn()+1);
			}
			else {
				res = new Guess(previousGuess.getRow(), previousGuess.getColumn()-1);
			}
			return res;
	//	}
		
		
		
		
/*
		Object[] map = HitChart(otherBoard);
		
		
		if (otherBoard.previousHit(comp.twoturnsGuess.getRow(), comp.twoturnsGuess.getColumn())) {
			if (comp.previousGuess.getRow()==comp.twoturnsGuess.getRow() && comp.previousGuess.getRow() < 7) {
				res = new Guess(comp.previousGuess.getRow(), comp.previousGuess.getColumn()+1);
			}
			res = new Guess(comp.previousGuess.getRow(), comp.previousGuess.getColumn()-1);
			
			
			
			
		}
		
		
		
		
		if (otherBoard.previousHit(comp.previousGuess.getRow(), comp.previousGuess.getColumn()) && otherBoard.previousHit(comp.twoturnsGuess.getRow(), comp.twoturnsGuess.getColumn())) { 
		
	}
	
	
	
}
	return res;
	
	
	
	
	public Object[] HitChart(Board otherBoard) {
		Object[] hits = new Object[49];
		int index = 0;
		for (int c = 0; c < 8; c++) {
			for (int r = 0; r < 8; r++) {
				if (otherBoard.previousHit(r, c)) {
					hits[index] = new Guess(r,c);
					index +=1;
				}
			}
		}
		return hits;
	
	*/
	}
}

